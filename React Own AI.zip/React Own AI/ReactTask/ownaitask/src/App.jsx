
import FormComponent from './Components/FormComponent'
import './App.css'

function App() {
  

  return (
    <>
      <FormComponent />
    </>
  )
}

export default App
