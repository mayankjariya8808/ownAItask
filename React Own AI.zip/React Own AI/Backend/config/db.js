const mongoose = require("mongoose");
// mongoose.connect('mongodb+srv://mayank:123@demo.9acz3tc.mongodb.net/')
// const db=mongoose.connection
// db.on('connected',()=>{
//     console.log("DataBase Connected Successfully");

// })

mongoose.connect("mongodb://127.0.0.1/task");
const db = mongoose.connection;
db.on("connected", () => {
  console.log("Database Connected Successfully");
});

module.export = db;
