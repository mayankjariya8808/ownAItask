const mongoose = require("mongoose");

const talentDetailSchema = new mongoose.Schema({
  jobtitle: { type: String, required: true },
  jobid: { type: String, required: true },
  contractDuration: { type: String },
  billRate: { type: String },
  talentcurrency: { type: String, default: "USD" },
  standardTimeBR: { type: String },
  overTimeBR: { type: String },
});

const formDataSchema = new mongoose.Schema({
  clientname: { type: String, required: true },
  purchasetype: { type: String, required: true },
  orderno: { type: String, required: true },
  receivedon: { type: Date, required: true },
  receivedfrom: { type: String },
  receivedemail: { type: String },
  postartdate: { type: Date, required: true },
  poenddate: { type: Date, required: true },
  budget: { type: String, required: true },
  currency: { type: String, default: "USD" },
  talentDetails: [talentDetailSchema], // Array of talent details
});

module.exports = mongoose.model("FormData", formDataSchema);
