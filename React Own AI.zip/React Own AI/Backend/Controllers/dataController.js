const mongoose = require("mongoose");
const StorageItem = require("../Modal/DataSchema");
const insert = async (req, res) => {
  const {
    clientname,
    purchasetype,
    orderno,
    receivedon,
    receivedfrom,
    receivedemail,
    postartdate,
    poenddate,
    budget,
    currency,
    jobtilte,
    jobid,
    contractduration,
    billdate,
    talentcurrency,
    standardTimeBR,
    overTimeBR,
  } = req.body;
  try {
    const newCustomer = dataTable.create({
      clientname,
      purchasetype,
      orderno,
      receivedon,
      receivedfrom,
      receivedemail,
      postartdate,
      poenddate,
      budget,
      currency,
      jobtilte,
      jobid,
      contractduration,
      billdate,
      talentcurrency,
      standardTimeBR,
      overTimeBR,
    });
    await newCustomer.save();
    res.status(201).json(newCustomer);
  } catch (error) {
    res.status(500).json({ error: "Error adding customer" });
  }
};

const addCustomer = async (req, res) => {
  const formData = req.body;
  console.log("Received data:", formData);
  res.status(200).send("Data inserted successfully");
};

module.exports = {
  addCustomer,
};
