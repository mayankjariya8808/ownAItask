const express = require("express");
const controllers = require("../Controllers/dataController");

const router = express.Router();

router.post("/api/insert", controllers.addCustomer);

module.exports = router;
