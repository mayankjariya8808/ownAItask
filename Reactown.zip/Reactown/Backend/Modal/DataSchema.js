const mongoose = require("mongoose");

// Define the talent schema
const talentSchema = new mongoose.Schema({
  jobtitle: { type: String, required: true },
  jobid: { type: String, required: true },
  contractDuration: { type: String, required: true },
  billRate: { type: String, required: true },
  standardTimeBR: { type: String, required: true },
  overTimeBR: { type: String, required: true },
  talentcurrency: { type: String, required: true },
});

// Define the main form schema, including talentDetails
const formDataSchema = new mongoose.Schema({
  clientname: { type: String, required: true },
  purchasetype: { type: String, required: true },
  orderno: { type: String, required: true },
  receivedon: { type: Date, required: true },
  receivedfrom: { type: String, required: true },
  receivedemail: { type: String, required: true },
  postartdate: { type: Date, required: true },
  poenddate: { type: Date },
  budget: { type: String, required: true },
  currency: { type: String, required: true },
  talentDetails: [talentSchema], // Array of talents based on talentSchema
});

// Create the model
const FormData = mongoose.model("FormData", formDataSchema);

module.exports = FormData;
