const express = require("express");
const controllers = require("../Controllers/dataController");

const router = express.Router();
router.use(express.json());

router.post("/insert", controllers.addCustomer);

module.exports = router;
