const mongoose = require("mongoose");
const FormData = require("../Modal/DataSchema");

const addCustomer = async (req, res) => {
  try {
    const newFormData = new FormData(req.body); 
    await newFormData.save(); 
    res.status(200).send("Data successfully saved!");
  } catch (error) {
    console.error("Error saving data:", error);
    res.status(500).send("Error saving data.");
  }
};

module.exports = {
  addCustomer,
};
