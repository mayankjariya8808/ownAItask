const mongoose = require("mongoose");
// mongoose.connect()
// const db=mongoose.connection
// db.on('connected',()=>{
//     console.log("DataBase Connected Successfully");

// })

mongoose.connect('mongodb+srv://mayank:123@demo.9acz3tc.mongodb.net/');
const db = mongoose.connection;
db.on("connected", () => {
  console.log("Database Connected Successfully");
});

module.export = db;
