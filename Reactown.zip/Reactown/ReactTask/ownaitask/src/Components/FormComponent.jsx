import React, { useState } from "react";
import { Form } from "react-bootstrap";
import Button from "react-bootstrap/Button";
import Swal from "sweetalert2";
import "../assets/Css/form.css";
import axios from "axios";

function FormComponent() {
  const [data, setData] = useState({
    clientname: "",
    purchasetype: "",
    orderno: "",
    receivedon: "",
    receivedfrom: "",
    receivedemail: "",
    postartdate: "",
    poenddate: "",
    budget: "",
    currency: "USD",
  });

  const [talentDetails, setTalentDetails] = useState([
    {
      jobtitle: "",
      jobid: "",
      contractDuration: "",
      billRate: "",
      talentcurrency: "USD",
      standardTimeBR: "",
      overTimeBR: "",
    },
  ]);

  const handleAddField = () => {
    setTalentDetails([
      ...talentDetails,
      {
        jobtitle: "",
        jobid: "",
        contractDuration: "",
        billRate: "",
        talentcurrency: "USD",
        standardTimeBR: "",
        overTimeBR: "",
      },
    ]);
  };

  const handleInputChange = (e, index = null) => {
    const { name, value } = e.target;

    if (index !== null) {
      const updatedTalentDetails = [...talentDetails];
      updatedTalentDetails[index][name] = value;
      setTalentDetails(updatedTalentDetails);
    } else {
      setData({
        ...data,
        [name]: value,
      });
    }
  };

  const handleDeleteField = (index) => {
    if (talentDetails.length > 1) {
      const updatedTalentDetails = talentDetails.filter((_, i) => i !== index);
      setTalentDetails(updatedTalentDetails);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = { ...data, talentDetails };
    console.log(formData);

    try {
      const response = await axios.post(
        "http://localhost:5000/insert", // Ensure this URL is correct
        formData
      );

      if (response.status === 200) {
        Swal.fire({
          title: "Good job!",
          text: "Data has been successfully saved!",
          icon: "success",
        });
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      Swal.fire({
        title: "Oopss....",
        text: "Something Went Wrong",
        icon: "error",
      });
    }
  };

  const handleReset = () => {
    setData({
      clientname: "",
      purchasetype: "",
      orderno: "",
      receivedon: "",
      receivedfrom: "",
      receivedemail: "",
      postartdate: "",
      poenddate: "",
      budget: "",
      currency: "USD",
    });

    setTalentDetails([
      {
        jobtitle: "",
        jobid: "",
        contractDuration: "",
        billRate: "",
        talentcurrency: "USD",
        standardTimeBR: "",
        overTimeBR: "",
      },
    ]);
  };

  return (
    <>
      <div className="mainContainer">
        <Form onSubmit={handleSubmit}>
          {/* Container 1: Main Information */}
          <div
            className="container1"
            style={{
              width: "100%",
              marginBottom: "20px",
              display: "flex",
              flexDirection: "row",
              flexWrap: "wrap",
              justifyContent: "space-evenly",
            }}
          >
            <div
              className="row1"
              style={{
                width: "100%",
                marginBottom: "20px",
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
                justifyContent: "space-evenly",
              }}
            >
              <Form.Group controlId="clientName">
                <Form.Label>
                  Client Name <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Client Name"
                  name="clientname"
                  value={data.clientname}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="poType">
                <Form.Label>
                  Purchase Order Type <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="PO Type"
                  name="purchasetype"
                  value={data.purchasetype}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="poNumber">
                <Form.Label>
                  Purchase Order No <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="PO Number"
                  name="orderno"
                  value={data.orderno}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="receivedOn">
                <Form.Label>
                  Received On <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="date"
                  name="receivedon"
                  value={data.receivedon}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="receivedFromName">
                <Form.Label>Received From</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Received From Name"
                  name="receivedfrom"
                  value={data.receivedfrom}
                  onChange={handleInputChange}
                />
              </Form.Group>
            </div>

            <div
              className="row2"
              style={{
                width: "100%",
                marginBottom: "20px",
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
                justifyContent: "space-evenly",
              }}
            >
              <Form.Group controlId="receivedFromEmail">
                <Form.Label>Received From Email</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Received From Email"
                  name="receivedemail"
                  value={data.receivedemail}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="startDate">
                <Form.Label>
                  PO Start Date <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="date"
                  name="postartdate"
                  value={data.postartdate}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="endDate">
                <Form.Label>
                  PO End Date <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="date"
                  name="poenddate"
                  value={data.poenddate}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="budget">
                <Form.Label>
                  Budget <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Budget"
                  name="budget"
                  value={data.budget}
                  onChange={handleInputChange}
                />
              </Form.Group>
              <Form.Group controlId="currency">
                <Form.Label>
                  Currency <span style={{ color: "red" }}>*</span>
                </Form.Label>
                <Form.Control
                  as="select"
                  defaultValue="USD"
                  name="currency"
                  value={data.currency}
                  onChange={handleInputChange}
                >
                  <option value="currency">USD - Dollars ($)</option>
                  <option value="currency">EUR - Euro (€)</option>
                </Form.Control>
              </Form.Group>
            </div>
          </div>

          {/* Talent Details Section */}
          <div className="talentdetailContainer">
            <h3>Talent Detail</h3>
            <Button
              className="addbtn"
              onClick={handleAddField}
              variant="outline-primary"
            >
              ADD ANOTHER
            </Button>
          </div>

          {/* Talent Detail Form */}
          {/* <div className="talentdetailform">
            {talentDetails.map((data, index) => (
              <div
                key={index}
                className="talentdetailformrow"
                style={{ marginBottom: "20px" }}
              >
                <div className="dynamicfields">
                  <div className="talentdetailformrow0">
                    <Form.Group controlId={`jobTitle-${index}`}>
                      <Form.Label>
                        Job Title / REQ Name{" "}
                        <span style={{ color: "red" }}>*</span>
                      </Form.Label>
                      <Form.Control
                        as="select"
                        name="jobtilte"
                        value={data.jobtilte}
                        onChange={(e) => handleInputChange(index, e)}
                      >
                        <option>APPLICATION DEVELOPMENT</option>
                        <option>2</option>
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId={`jobId-${index}`}>
                      <Form.Label>
                        Job ID / REQ ID <span style={{ color: "red" }}>*</span>
                      </Form.Label>
                      <Form.Control
                        type="text"
                        name="jobid"
                        placeholder="Job ID"
                        value={data.jobid}
                        onChange={(e) => handleInputChange(index, e)}
                      />
                    </Form.Group>

                    <Button
                      className="deletebtn"
                      onClick={() => handleDeleteField(index)}
                    >
                      <i className="fa-solid fa-trash"></i>
                    </Button>
                  </div>

                  <div className="talentdetailformrow">
                    <Form.Group controlId={`contractDuration-${index}`}>
                      <Form.Label>Contract Duration</Form.Label>
                      <Form.Control
                        type="text"
                        name="contractDuration"
                        placeholder="Months"
                        value={data.contractDuration}
                        onChange={(e) => handleInputChange(index, e)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`billRate-${index}`}>
                      <Form.Label>Bill Rate</Form.Label>
                      <Form.Control
                        type="text"
                        name="billRate"
                        placeholder="Bill Rate"
                        value={data.billRate}
                        onChange={(e) => handleInputChange(index, e)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`currency-${index}`}>
                      <Form.Label>Currency</Form.Label>
                      <Form.Control
                        as="select"
                        name="currency"
                        value={data.talentcurrency}
                        onChange={(e) => handleInputChange(index, e)}
                      >
                        <option>USD - Dollars ($)</option>
                        <option>EUR - Euro (€)</option>
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId={`standardTimeBR-${index}`}>
                      <Form.Label>Standard Time BR</Form.Label>
                      <Form.Control
                        type="text"
                        name="standardTimeBR"
                        placeholder="Standard Time Bill Rate"
                        value={data.standardTimeBR}
                        onChange={(e) => handleInputChange(index, e)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`overTimeBR-${index}`}>
                      <Form.Label>Over Time BR</Form.Label>
                      <Form.Control
                        type="text"
                        name="overTimeBR"
                        placeholder="Over Time Bill Rate"
                        value={data.overTimeBR}
                        onChange={(e) => handleInputChange(index, e)}
                      />
                    </Form.Group>
                  </div>
                </div>
              </div>
            ))}
          </div> */}
          {/* Talent Detail Form */}
          <div className="talentdetailform">
            {talentDetails.map((talent, index) => (
              <div
                key={index}
                className="talentdetailformrow"
                style={{ marginBottom: "20px" }}
              >
                <div className="dynamicfields">
                  <div className="talentdetailformrow0">
                    <Form.Group controlId={`jobTitle-${index}`}>
                      <Form.Label>
                        Job Title / REQ Name{" "}
                        <span style={{ color: "red" }}>*</span>
                      </Form.Label>
                      <Form.Control
                        as="select"
                        name="jobtitle"
                        value={talent.jobtitle}
                        onChange={(e) => handleInputChange(e, index)}
                      >
                        <option value="APPLICATION DEVELOPMENT">
                          APPLICATION DEVELOPMENT
                        </option>
                        <option value="2">2</option>
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId={`jobId-${index}`}>
                      <Form.Label>
                        Job ID / REQ ID <span style={{ color: "red" }}>*</span>
                      </Form.Label>
                      <Form.Control
                        type="text"
                        name="jobid"
                        placeholder="Job ID"
                        value={talent.jobid}
                        onChange={(e) => handleInputChange(e, index)}
                      />
                    </Form.Group>

                    <Button
                      className="deletebtn"
                      onClick={() => handleDeleteField(index)}
                    >
                      <i className="fa-solid fa-trash"></i>
                    </Button>
                  </div>

                  <div className="talentdetailformrow">
                    <Form.Group controlId={`contractDuration-${index}`}>
                      <Form.Label>Contract Duration</Form.Label>
                      <Form.Control
                        type="text"
                        name="contractDuration"
                        placeholder="Months"
                        value={talent.contractDuration}
                        onChange={(e) => handleInputChange(e, index)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`billRate-${index}`}>
                      <Form.Label>Bill Rate</Form.Label>
                      <Form.Control
                        type="text"
                        name="billRate"
                        placeholder="Bill Rate"
                        value={talent.billRate}
                        onChange={(e) => handleInputChange(e, index)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`currency-${index}`}>
                      <Form.Label>Currency</Form.Label>
                      <Form.Control
                        as="select"
                        name="talentcurrency"
                        value={talent.talentcurrency}
                        onChange={(e) => handleInputChange(e, index)}
                      >
                        <option>USD - Dollars ($)</option>
                        <option>EUR - Euro (€)</option>
                      </Form.Control>
                    </Form.Group>

                    <Form.Group controlId={`standardTimeBR-${index}`}>
                      <Form.Label>Standard Time BR</Form.Label>
                      <Form.Control
                        type="text"
                        name="standardTimeBR"
                        placeholder="Standard Time Bill Rate"
                        value={talent.standardTimeBR}
                        onChange={(e) => handleInputChange(e, index)}
                      />
                    </Form.Group>

                    <Form.Group controlId={`overTimeBR-${index}`}>
                      <Form.Label>Over Time BR</Form.Label>
                      <Form.Control
                        type="text"
                        name="overTimeBR"
                        placeholder="Over Time Bill Rate"
                        value={talent.overTimeBR}
                        onChange={(e) => handleInputChange(e, index)}
                      />
                    </Form.Group>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ textAlign: "right", marginTop: "20px" }}>
            <Button
              className="formbtn"
              variant="secondary"
              style={{ marginRight: "10px" }}
              onClick={handleReset}
            >
              Reset
            </Button>
            <Button className="formbtn" type="submit" variant="primary">
              Save
            </Button>
          </div>
        </Form>
      </div>
    </>
  );
}

export default FormComponent;
